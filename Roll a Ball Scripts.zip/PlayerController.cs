﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerController : MonoBehaviour {

	public float speed;
	public Text countText;
	public Text winText;
	public Text scoreText;

	private Rigidbody rb;
	private int count;
	private int score;

	void Start ()
	{
		rb = GetComponent<Rigidbody>();
		score = 0;
		count = 0;
		SetAllText ();
		winText.text = "";
		scoreText.text = "";
	}

	void Update ()
	{
		if (Input.GetKey ("escape")) 
		{
			Application.Quit ();
		}
	}

	void FixedUpdate ()
	{
		float moveHorizontal = Input.GetAxis ("Horizontal");
		float moveVertical = Input.GetAxis ("Vertical");

		Vector3 movement = new Vector3 (moveHorizontal, 0.0f, moveVertical);

		rb.AddForce (movement * speed);
	}
		
		private void OnTriggerEnter(Collider other)
		{
			if (other.gameObject.CompareTag("Pick Up"))
			{
				other.gameObject.SetActive(false);
				count = count + 1;
				score = score + 1; // I added this to start tracking score and count separate.
			    SetAllText();
			}
			else if (other.gameObject.CompareTag("Enemy"))
			{
				other.gameObject.SetActive(false);
				score = score - 1; // this removes 1 from the score
				SetAllText();
			}
		} 

	void SetAllText()
	{
		countText.text = "Count: " + count.ToString ();
		if (count >= 12)
		{
			winText.text = "You won with game with a score of: " + count.ToString();
		}
	}
		
}
